-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: inventory_system
-- ------------------------------------------------------
-- Server version	8.4.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `inventory_system`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `inventory_system` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `inventory_system`;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` bigint NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` bigint NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_locks_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_locks`
--

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`),
  KEY `failed_jobs_connection_queue_failed_at_index` (`connection`,`queue`,`failed_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flower_exits`
--

DROP TABLE IF EXISTS `flower_exits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `flower_exits` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `flower_product_id` bigint unsigned NOT NULL,
  `quantity` decimal(15,3) unsigned NOT NULL,
  `exit_date` date NOT NULL,
  `exit_type` enum('gift','internal_use','sample','other') COLLATE utf8mb4_unicode_ci NOT NULL,
  `recipient_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `status` enum('confirmed','cancelled') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'confirmed',
  `created_by` bigint unsigned NOT NULL,
  `confirmed_by` bigint unsigned DEFAULT NULL,
  `confirmed_at` timestamp NULL DEFAULT NULL,
  `cancelled_by` bigint unsigned DEFAULT NULL,
  `cancelled_at` timestamp NULL DEFAULT NULL,
  `cancellation_reason` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `flower_exits_created_by_foreign` (`created_by`),
  KEY `flower_exits_confirmed_by_foreign` (`confirmed_by`),
  KEY `flower_exits_cancelled_by_foreign` (`cancelled_by`),
  KEY `flower_exits_flower_product_id_exit_date_index` (`flower_product_id`,`exit_date`),
  KEY `flower_exits_status_exit_date_index` (`status`,`exit_date`),
  KEY `flower_exits_exit_type_index` (`exit_type`),
  CONSTRAINT `flower_exits_cancelled_by_foreign` FOREIGN KEY (`cancelled_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `flower_exits_confirmed_by_foreign` FOREIGN KEY (`confirmed_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `flower_exits_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `flower_exits_flower_product_id_foreign` FOREIGN KEY (`flower_product_id`) REFERENCES `flower_products` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `flower_exits_quantity_check` CHECK ((`quantity` > 0))
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flower_exits`
--

LOCK TABLES `flower_exits` WRITE;
/*!40000 ALTER TABLE `flower_exits` DISABLE KEYS */;
INSERT INTO `flower_exits` VALUES (4,15,12.000,'2026-08-21','gift','مناسبة عائلية','خروج غير بيعي تجريبي','confirmed',12,12,'2026-08-21 20:14:56',NULL,NULL,NULL,'2026-08-21 20:14:56','2026-08-21 20:14:56');
/*!40000 ALTER TABLE `flower_exits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flower_invoice_items`
--

DROP TABLE IF EXISTS `flower_invoice_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `flower_invoice_items` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `invoice_id` bigint unsigned NOT NULL,
  `flower_product_id` bigint unsigned NOT NULL,
  `product_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `color` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `unit` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` decimal(15,3) unsigned NOT NULL,
  `unit_price` decimal(12,3) unsigned NOT NULL,
  `line_total` decimal(14,3) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `flower_invoice_product_unique` (`invoice_id`,`flower_product_id`),
  KEY `flower_invoice_items_flower_product_id_index` (`flower_product_id`),
  CONSTRAINT `flower_invoice_items_flower_product_id_foreign` FOREIGN KEY (`flower_product_id`) REFERENCES `flower_products` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `flower_invoice_items_invoice_id_foreign` FOREIGN KEY (`invoice_id`) REFERENCES `flower_invoices` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `flower_invoice_items_quantity_check` CHECK ((`quantity` > 0))
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flower_invoice_items`
--

LOCK TABLES `flower_invoice_items` WRITE;
/*!40000 ALTER TABLE `flower_invoice_items` DISABLE KEYS */;
INSERT INTO `flower_invoice_items` VALUES (1,1,14,'جوري','أحمر','ربطة',90.000,22.000,1980.000,'2026-08-21 20:14:55','2026-08-21 20:14:55'),(2,1,15,'جوري','أبيض','ربطة',60.000,22.000,1320.000,'2026-08-21 20:14:55','2026-08-21 20:14:55'),(3,2,16,'توليب','أصفر','ربطة',45.000,28.000,1260.000,'2026-08-21 20:14:56','2026-08-21 20:14:56'),(4,3,17,'ليليوم','أبيض','ربطة',10.000,38.000,380.000,'2026-08-21 20:14:56','2026-08-21 20:14:56');
/*!40000 ALTER TABLE `flower_invoice_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flower_invoices`
--

DROP TABLE IF EXISTS `flower_invoices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `flower_invoices` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `invoice_number` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `recipient_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `invoice_date` date NOT NULL,
  `payment_type` enum('cash','credit','partial') COLLATE utf8mb4_unicode_ci NOT NULL,
  `payment_status` enum('paid','partial','unpaid') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'unpaid',
  `subtotal_amount` decimal(14,3) unsigned NOT NULL DEFAULT '0.000',
  `discount_amount` decimal(14,3) unsigned NOT NULL DEFAULT '0.000',
  `total_amount` decimal(14,3) unsigned NOT NULL DEFAULT '0.000',
  `paid_amount` decimal(14,3) unsigned NOT NULL DEFAULT '0.000',
  `remaining_amount` decimal(14,3) unsigned NOT NULL DEFAULT '0.000',
  `status` enum('draft','confirmed','cancelled') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'draft',
  `notes` text COLLATE utf8mb4_unicode_ci,
  `created_by` bigint unsigned NOT NULL,
  `confirmed_by` bigint unsigned DEFAULT NULL,
  `confirmed_at` timestamp NULL DEFAULT NULL,
  `cancelled_by` bigint unsigned DEFAULT NULL,
  `cancelled_at` timestamp NULL DEFAULT NULL,
  `cancellation_reason` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `updated_by` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `flower_invoices_invoice_number_unique` (`invoice_number`),
  KEY `flower_invoices_created_by_foreign` (`created_by`),
  KEY `flower_invoices_confirmed_by_foreign` (`confirmed_by`),
  KEY `flower_invoices_cancelled_by_foreign` (`cancelled_by`),
  KEY `flower_invoices_status_invoice_date_index` (`status`,`invoice_date`),
  KEY `flower_invoices_payment_status_index` (`payment_status`),
  KEY `flower_invoices_recipient_name_index` (`recipient_name`),
  KEY `flower_invoices_updated_by_foreign` (`updated_by`),
  CONSTRAINT `flower_invoices_cancelled_by_foreign` FOREIGN KEY (`cancelled_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `flower_invoices_confirmed_by_foreign` FOREIGN KEY (`confirmed_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `flower_invoices_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `flower_invoices_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `flower_invoices_amounts_check` CHECK (((`discount_amount` <= `subtotal_amount`) and (`total_amount` = (`subtotal_amount` - `discount_amount`)) and (`paid_amount` <= `total_amount`) and (`remaining_amount` = (`total_amount` - `paid_amount`))))
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flower_invoices`
--

LOCK TABLES `flower_invoices` WRITE;
/*!40000 ALTER TABLE `flower_invoices` DISABLE KEYS */;
INSERT INTO `flower_invoices` VALUES (1,'FL-I-01M0JZCNEXBGEZ8V6SZ4JPCK55','قاعة أفراح النخيل','2026-08-20','partial','partial',3300.000,0.000,3300.000,2000.000,1300.000,'confirmed','فاتورة ورد تجريبية',12,12,'2026-08-21 20:14:56',NULL,NULL,NULL,'2026-08-21 20:14:55','2026-08-21 20:14:56',NULL),(2,'FL-I-01M0JZCNHFDSE9K6RGD2ZF7RXX','محل زهور طرابلس','2026-08-21','partial','partial',1260.000,0.000,1260.000,500.000,760.000,'confirmed',NULL,12,12,'2026-08-21 20:14:56',NULL,NULL,NULL,'2026-08-21 20:14:56','2026-08-21 20:14:56',NULL),(3,'FL-I-01M0JZCNKA6AVZEDW0BQWW3GPT','مسودة بدون اعتماد','2026-08-21','credit','unpaid',380.000,0.000,380.000,0.000,380.000,'draft',NULL,12,NULL,NULL,NULL,NULL,NULL,'2026-08-21 20:14:56','2026-08-21 20:14:56',NULL);
/*!40000 ALTER TABLE `flower_invoices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flower_products`
--

DROP TABLE IF EXISTS `flower_products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `flower_products` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `company_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `color` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `grade` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `unit` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `current_quantity` decimal(15,3) unsigned NOT NULL DEFAULT '0.000',
  `purchase_price` decimal(12,3) unsigned DEFAULT NULL,
  `sale_price` decimal(12,3) unsigned DEFAULT NULL,
  `minimum_quantity` decimal(15,3) unsigned DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_by` bigint unsigned DEFAULT NULL,
  `updated_by` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `flower_products_code_unique` (`code`),
  KEY `flower_products_created_by_foreign` (`created_by`),
  KEY `flower_products_updated_by_foreign` (`updated_by`),
  KEY `flower_products_is_active_current_quantity_index` (`is_active`,`current_quantity`),
  KEY `flower_products_name_color_index` (`name`,`color`),
  KEY `flower_products_company_name_index` (`company_name`),
  CONSTRAINT `flower_products_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `flower_products_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flower_products`
--

LOCK TABLES `flower_products` WRITE;
/*!40000 ALTER TABLE `flower_products` DISABLE KEYS */;
INSERT INTO `flower_products` VALUES (14,'جوري','مزارع الجبل','FL-001','أحمر','درجة أولى','ربطة',272.000,15.000,22.000,30.000,NULL,1,12,NULL,'2026-08-21 20:14:54','2026-08-21 20:14:56'),(15,'جوري','مزارع الجبل','FL-002','أبيض','درجة أولى','ربطة',213.000,15.000,22.000,25.000,NULL,1,12,NULL,'2026-08-21 20:14:54','2026-08-21 20:14:56'),(16,'توليب','هولندا فلور','FL-003','أصفر','درجة أولى','ربطة',220.000,18.000,28.000,20.000,NULL,1,12,NULL,'2026-08-21 20:14:54','2026-08-21 20:14:56'),(17,'ليليوم','فلورز العالمية','FL-004','أبيض','ممتاز','ربطة',112.000,25.000,38.000,15.000,NULL,1,12,NULL,'2026-08-21 20:14:54','2026-08-21 20:14:55'),(18,'توليب','مزارع المتوسط','FL-005','أصفر','ممتاز','ربطة',90.000,20.000,31.000,18.000,NULL,1,12,NULL,'2026-08-21 20:15:29','2026-08-21 20:15:29');
/*!40000 ALTER TABLE `flower_products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flower_receipt_items`
--

DROP TABLE IF EXISTS `flower_receipt_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `flower_receipt_items` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `receipt_id` bigint unsigned NOT NULL,
  `flower_product_id` bigint unsigned NOT NULL,
  `product_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `color` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `unit` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expected_quantity` decimal(15,3) unsigned NOT NULL DEFAULT '0.000',
  `received_quantity` decimal(15,3) unsigned NOT NULL DEFAULT '0.000',
  `damaged_quantity` decimal(15,3) unsigned NOT NULL DEFAULT '0.000',
  `shortage_quantity` decimal(15,3) unsigned NOT NULL DEFAULT '0.000',
  `surplus_quantity` decimal(15,3) unsigned NOT NULL DEFAULT '0.000',
  `accepted_quantity` decimal(15,3) unsigned NOT NULL DEFAULT '0.000',
  `purchase_price` decimal(12,3) unsigned DEFAULT NULL,
  `balance_before` decimal(15,3) unsigned DEFAULT NULL,
  `balance_after` decimal(15,3) unsigned DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `flower_receipt_product_unique` (`receipt_id`,`flower_product_id`),
  KEY `flower_receipt_items_flower_product_id_index` (`flower_product_id`),
  CONSTRAINT `flower_receipt_items_flower_product_id_foreign` FOREIGN KEY (`flower_product_id`) REFERENCES `flower_products` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `flower_receipt_items_receipt_id_foreign` FOREIGN KEY (`receipt_id`) REFERENCES `flower_receipts` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `flower_receipt_items_quantities_check` CHECK (((`damaged_quantity` <= `received_quantity`) and (`shortage_quantity` = (case when (`expected_quantity` > `received_quantity`) then (`expected_quantity` - `received_quantity`) else 0 end)) and (`surplus_quantity` = (case when (`received_quantity` > `expected_quantity`) then (`received_quantity` - `expected_quantity`) else 0 end)) and (`accepted_quantity` = (`received_quantity` - `damaged_quantity`))))
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flower_receipt_items`
--

LOCK TABLES `flower_receipt_items` WRITE;
/*!40000 ALTER TABLE `flower_receipt_items` DISABLE KEYS */;
INSERT INTO `flower_receipt_items` VALUES (8,7,14,'جوري','أحمر','ربطة',300.000,280.000,10.000,20.000,0.000,270.000,15.000,100.000,370.000,NULL,'2026-08-21 20:14:55','2026-08-21 20:14:55'),(9,7,15,'جوري','أبيض','ربطة',200.000,220.000,5.000,0.000,20.000,215.000,15.000,70.000,285.000,NULL,'2026-08-21 20:14:55','2026-08-21 20:14:55'),(10,8,16,'توليب','أصفر','ربطة',160.000,150.000,0.000,10.000,0.000,150.000,18.000,120.000,270.000,NULL,'2026-08-21 20:14:55','2026-08-21 20:14:55'),(11,8,17,'ليليوم','أبيض','ربطة',80.000,75.000,3.000,5.000,0.000,72.000,25.000,40.000,112.000,NULL,'2026-08-21 20:14:55','2026-08-21 20:14:55'),(12,9,14,'جوري','أحمر','ربطة',100.000,90.000,0.000,10.000,0.000,90.000,15.000,NULL,NULL,NULL,'2026-08-21 20:14:55','2026-08-21 20:14:55');
/*!40000 ALTER TABLE `flower_receipt_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flower_receipts`
--

DROP TABLE IF EXISTS `flower_receipts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `flower_receipts` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `receipt_number` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `supplier_id` bigint unsigned NOT NULL,
  `supplier_invoice_number` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `receipt_date` date NOT NULL,
  `status` enum('draft','confirmed','cancelled') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'draft',
  `notes` text COLLATE utf8mb4_unicode_ci,
  `created_by` bigint unsigned NOT NULL,
  `confirmed_by` bigint unsigned DEFAULT NULL,
  `confirmed_at` timestamp NULL DEFAULT NULL,
  `cancelled_by` bigint unsigned DEFAULT NULL,
  `cancelled_at` timestamp NULL DEFAULT NULL,
  `cancellation_reason` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `updated_by` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `flower_receipts_receipt_number_unique` (`receipt_number`),
  KEY `flower_receipts_created_by_foreign` (`created_by`),
  KEY `flower_receipts_confirmed_by_foreign` (`confirmed_by`),
  KEY `flower_receipts_cancelled_by_foreign` (`cancelled_by`),
  KEY `flower_receipts_supplier_id_receipt_date_index` (`supplier_id`,`receipt_date`),
  KEY `flower_receipts_status_receipt_date_index` (`status`,`receipt_date`),
  KEY `flower_receipts_supplier_invoice_number_index` (`supplier_invoice_number`),
  KEY `flower_receipts_updated_by_foreign` (`updated_by`),
  CONSTRAINT `flower_receipts_cancelled_by_foreign` FOREIGN KEY (`cancelled_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `flower_receipts_confirmed_by_foreign` FOREIGN KEY (`confirmed_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `flower_receipts_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `flower_receipts_supplier_id_foreign` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `flower_receipts_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flower_receipts`
--

LOCK TABLES `flower_receipts` WRITE;
/*!40000 ALTER TABLE `flower_receipts` DISABLE KEYS */;
INSERT INTO `flower_receipts` VALUES (7,'FL-R-01M0JZCN70CA8EPW17430VBMQD',9,'SUP-FL-2001','2026-08-19','confirmed','استلام ورد مع تالف عند الوصول',12,12,'2026-08-21 20:14:55',NULL,NULL,NULL,'2026-08-21 20:14:55','2026-08-21 20:14:55',NULL),(8,'FL-R-01M0JZCNAZW30FBE6H20A7VYT8',10,'SUP-FL-2002','2026-08-21','confirmed',NULL,12,12,'2026-08-21 20:14:55',NULL,NULL,NULL,'2026-08-21 20:14:55','2026-08-21 20:14:55',NULL),(9,'FL-R-01M0JZCNDR8EE9QNG4K97668KH',9,NULL,'2026-08-21','draft','مسودة استلام ورد',12,NULL,NULL,NULL,NULL,NULL,'2026-08-21 20:14:55','2026-08-21 20:14:55',NULL);
/*!40000 ALTER TABLE `flower_receipts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoice_payments`
--

DROP TABLE IF EXISTS `invoice_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `invoice_payments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `invoiceable_type` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `invoiceable_id` bigint unsigned NOT NULL,
  `amount` decimal(14,3) unsigned NOT NULL,
  `paid_at` timestamp NOT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `created_by` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `invoice_payments_created_by_foreign` (`created_by`),
  KEY `invoice_payments_invoiceable_index` (`invoiceable_type`,`invoiceable_id`),
  KEY `invoice_payments_paid_at_index` (`paid_at`),
  CONSTRAINT `invoice_payments_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `invoice_payments_amount_check` CHECK ((`amount` > 0))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoice_payments`
--

LOCK TABLES `invoice_payments` WRITE;
/*!40000 ALTER TABLE `invoice_payments` DISABLE KEYS */;
INSERT INTO `invoice_payments` VALUES (1,'salami_invoice',2,500.000,'2026-08-21 20:31:32',NULL,12,'2026-08-21 20:31:32','2026-08-21 20:31:32');
/*!40000 ALTER TABLE `invoice_payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_batches`
--

DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_batches` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_jobs` int NOT NULL,
  `pending_jobs` int NOT NULL,
  `failed_jobs` int NOT NULL,
  `failed_job_ids` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `options` mediumtext COLLATE utf8mb4_unicode_ci,
  `cancelled_at` int DEFAULT NULL,
  `created_at` int NOT NULL,
  `finished_at` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_batches`
--

LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` smallint unsigned NOT NULL,
  `reserved_at` int unsigned DEFAULT NULL,
  `available_at` int unsigned NOT NULL,
  `created_at` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'0001_01_01_000000_create_users_table',1),(2,'0001_01_01_000001_create_cache_table',1),(3,'0001_01_01_000002_create_jobs_table',1),(4,'2026_08_20_100000_add_role_and_is_active_to_users_table',1),(5,'2026_08_20_110000_create_suppliers_table',1),(6,'2026_08_20_111000_create_salami_products_table',1),(7,'2026_08_20_112000_create_salami_customers_table',1),(8,'2026_08_20_113000_create_salami_receipts_table',1),(9,'2026_08_20_114000_create_salami_receipt_items_table',1),(10,'2026_08_20_115000_create_salami_invoices_table',1),(11,'2026_08_20_116000_create_salami_invoice_items_table',1),(12,'2026_08_20_117000_create_flower_products_table',1),(13,'2026_08_20_118000_create_flower_receipts_table',1),(14,'2026_08_20_119000_create_flower_receipt_items_table',1),(15,'2026_08_20_120000_create_flower_invoices_table',1),(16,'2026_08_20_121000_create_flower_invoice_items_table',1),(17,'2026_08_20_122000_create_flower_exits_table',1),(18,'2026_08_20_123000_create_stock_movements_table',1),(19,'2026_08_20_124000_create_stock_wastes_table',1),(20,'2026_08_20_125000_create_stock_adjustments_table',1),(21,'2026_08_20_126000_create_stock_openings_table',1),(22,'2026_08_20_127000_add_updated_by_to_documents_table',1),(23,'2026_08_20_128000_fix_stock_adjustment_difference_check',1),(24,'2026_08_20_129000_add_color_snapshot_to_flower_receipt_items_table',1),(25,'2026_08_20_130000_add_color_to_flower_invoice_items_table',1),(26,'2026_08_21_100000_create_invoice_payments_table',1),(27,'2026_08_21_101000_add_company_name_to_flower_products_table',1),(28,'2026_08_25_102000_create_salami_delivery_agents_table',2),(29,'2026_08_25_103000_add_delivery_agent_to_salami_customers_and_invoices',2),(30,'2026_08_25_104000_add_variable_package_quantities_to_salami_documents',2);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `salami_customers`
--

DROP TABLE IF EXISTS `salami_customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `salami_customers` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `delivery_agent_id` bigint unsigned DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contact_person` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `area` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_by` bigint unsigned DEFAULT NULL,
  `updated_by` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `salami_customers_created_by_foreign` (`created_by`),
  KEY `salami_customers_updated_by_foreign` (`updated_by`),
  KEY `salami_customers_is_active_name_index` (`is_active`,`name`),
  KEY `salami_customers_phone_index` (`phone`),
  KEY `salami_customers_delivery_agent_id_is_active_index` (`delivery_agent_id`,`is_active`),
  CONSTRAINT `salami_customers_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `salami_customers_delivery_agent_id_foreign` FOREIGN KEY (`delivery_agent_id`) REFERENCES `salami_delivery_agents` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `salami_customers_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `salami_customers`
--

LOCK TABLES `salami_customers` WRITE;
/*!40000 ALTER TABLE `salami_customers` DISABLE KEYS */;
INSERT INTO `salami_customers` VALUES (1,1,'محل الوداد','مصطفى','0910000010','سوق الجمعة',NULL,NULL,1,NULL,NULL,'2026-08-21 20:14:54','2026-08-25 16:45:35'),(2,1,'سوبر ماركت النخيل','سالم','0910000011','طرابلس المركز',NULL,NULL,1,NULL,NULL,'2026-08-21 20:14:54','2026-08-25 16:45:35'),(3,2,'مخزن باب البحر','علي','0910000012','باب البحر',NULL,NULL,1,NULL,NULL,'2026-08-21 20:14:54','2026-08-25 16:45:35');
/*!40000 ALTER TABLE `salami_customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `salami_delivery_agents`
--

DROP TABLE IF EXISTS `salami_delivery_agents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `salami_delivery_agents` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_by` bigint unsigned DEFAULT NULL,
  `updated_by` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `salami_delivery_agents_created_by_foreign` (`created_by`),
  KEY `salami_delivery_agents_updated_by_foreign` (`updated_by`),
  KEY `salami_delivery_agents_is_active_name_index` (`is_active`,`name`),
  CONSTRAINT `salami_delivery_agents_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `salami_delivery_agents_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `salami_delivery_agents`
--

LOCK TABLES `salami_delivery_agents` WRITE;
/*!40000 ALTER TABLE `salami_delivery_agents` DISABLE KEYS */;
INSERT INTO `salami_delivery_agents` VALUES (1,'محمد الورفلي','0910000020',NULL,1,12,NULL,'2026-08-25 16:45:35','2026-08-25 16:45:35'),(2,'سالم الفيتوري','0910000021',NULL,1,12,NULL,'2026-08-25 16:45:35','2026-08-25 16:45:35');
/*!40000 ALTER TABLE `salami_delivery_agents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `salami_invoice_items`
--

DROP TABLE IF EXISTS `salami_invoice_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `salami_invoice_items` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `invoice_id` bigint unsigned NOT NULL,
  `product_id` bigint unsigned NOT NULL,
  `product_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `unit` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `conversion_factor` decimal(15,3) unsigned NOT NULL DEFAULT '1.000',
  `quantity` decimal(15,3) unsigned NOT NULL,
  `stock_quantity` decimal(15,3) unsigned NOT NULL DEFAULT '0.000',
  `unit_price` decimal(12,3) unsigned NOT NULL,
  `line_total` decimal(14,3) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `salami_invoice_items_invoice_id_product_id_unique` (`invoice_id`,`product_id`),
  KEY `salami_invoice_items_product_id_index` (`product_id`),
  CONSTRAINT `salami_invoice_items_invoice_id_foreign` FOREIGN KEY (`invoice_id`) REFERENCES `salami_invoices` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `salami_invoice_items_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `salami_products` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `salami_invoice_items_quantity_check` CHECK ((`quantity` > 0))
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `salami_invoice_items`
--

LOCK TABLES `salami_invoice_items` WRITE;
/*!40000 ALTER TABLE `salami_invoice_items` DISABLE KEYS */;
INSERT INTO `salami_invoice_items` VALUES (1,1,1,'سلامي سادة','صندوق',1.000,18.000,18.000,100.000,1800.000,'2026-08-21 20:14:55','2026-08-21 20:14:55'),(2,1,2,'سلامي حار','صندوق',1.000,10.000,10.000,110.000,1100.000,'2026-08-21 20:14:55','2026-08-21 20:14:55'),(3,2,3,'سلامي مدخن','صندوق',1.000,8.000,8.000,125.000,1000.000,'2026-08-21 20:14:55','2026-08-21 20:14:55'),(4,3,4,'سلامي شرائح','صندوق',1.000,5.000,5.000,92.000,460.000,'2026-08-21 20:14:55','2026-08-21 20:14:55');
/*!40000 ALTER TABLE `salami_invoice_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `salami_invoices`
--

DROP TABLE IF EXISTS `salami_invoices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `salami_invoices` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `invoice_number` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_id` bigint unsigned NOT NULL,
  `delivery_agent_id` bigint unsigned DEFAULT NULL,
  `invoice_date` date NOT NULL,
  `payment_type` enum('cash','credit','partial') COLLATE utf8mb4_unicode_ci NOT NULL,
  `payment_status` enum('paid','partial','unpaid') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'unpaid',
  `subtotal_amount` decimal(14,3) unsigned NOT NULL DEFAULT '0.000',
  `discount_amount` decimal(14,3) unsigned NOT NULL DEFAULT '0.000',
  `total_amount` decimal(14,3) unsigned NOT NULL DEFAULT '0.000',
  `paid_amount` decimal(14,3) unsigned NOT NULL DEFAULT '0.000',
  `remaining_amount` decimal(14,3) unsigned NOT NULL DEFAULT '0.000',
  `status` enum('draft','confirmed','cancelled') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'draft',
  `notes` text COLLATE utf8mb4_unicode_ci,
  `created_by` bigint unsigned NOT NULL,
  `confirmed_by` bigint unsigned DEFAULT NULL,
  `confirmed_at` timestamp NULL DEFAULT NULL,
  `cancelled_by` bigint unsigned DEFAULT NULL,
  `cancelled_at` timestamp NULL DEFAULT NULL,
  `cancellation_reason` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `updated_by` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `salami_invoices_invoice_number_unique` (`invoice_number`),
  KEY `salami_invoices_created_by_foreign` (`created_by`),
  KEY `salami_invoices_confirmed_by_foreign` (`confirmed_by`),
  KEY `salami_invoices_cancelled_by_foreign` (`cancelled_by`),
  KEY `salami_invoices_customer_id_invoice_date_index` (`customer_id`,`invoice_date`),
  KEY `salami_invoices_status_invoice_date_index` (`status`,`invoice_date`),
  KEY `salami_invoices_payment_status_index` (`payment_status`),
  KEY `salami_invoices_updated_by_foreign` (`updated_by`),
  KEY `salami_invoices_delivery_agent_id_invoice_date_index` (`delivery_agent_id`,`invoice_date`),
  CONSTRAINT `salami_invoices_cancelled_by_foreign` FOREIGN KEY (`cancelled_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `salami_invoices_confirmed_by_foreign` FOREIGN KEY (`confirmed_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `salami_invoices_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `salami_invoices_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `salami_customers` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `salami_invoices_delivery_agent_id_foreign` FOREIGN KEY (`delivery_agent_id`) REFERENCES `salami_delivery_agents` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `salami_invoices_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `salami_invoices_amounts_check` CHECK (((`discount_amount` <= `subtotal_amount`) and (`total_amount` = (`subtotal_amount` - `discount_amount`)) and (`paid_amount` <= `total_amount`) and (`remaining_amount` = (`total_amount` - `paid_amount`))))
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `salami_invoices`
--

LOCK TABLES `salami_invoices` WRITE;
/*!40000 ALTER TABLE `salami_invoices` DISABLE KEYS */;
INSERT INTO `salami_invoices` VALUES (1,'SAL-I-01M0JZCMQF7DSXGSWMDQQ6N4JS',1,1,'2026-08-19','partial','partial',2900.000,0.000,2900.000,1000.000,1900.000,'confirmed','فاتورة تجريبية',12,12,'2026-08-21 20:14:55',NULL,NULL,NULL,'2026-08-21 20:14:55','2026-08-21 20:14:55',NULL),(2,'SAL-I-01M0JZCMYBP880K4P9CE1R50SD',2,1,'2026-08-20','partial','paid',1000.000,0.000,1000.000,1000.000,0.000,'confirmed',NULL,12,12,'2026-08-21 20:14:55',NULL,NULL,NULL,'2026-08-21 20:14:55','2026-08-21 20:31:32',12),(3,'SAL-I-01M0JZCN24TMDH39TJAFNS3XEZ',3,2,'2026-08-21','credit','unpaid',460.000,0.000,460.000,0.000,460.000,'draft','فاتورة مسودة للعرض',12,NULL,NULL,NULL,NULL,NULL,'2026-08-21 20:14:55','2026-08-21 20:14:55',NULL);
/*!40000 ALTER TABLE `salami_invoices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `salami_products`
--

DROP TABLE IF EXISTS `salami_products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `salami_products` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `unit` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `current_quantity` decimal(15,3) unsigned NOT NULL DEFAULT '0.000',
  `purchase_price` decimal(12,3) unsigned DEFAULT NULL,
  `sale_price` decimal(12,3) unsigned DEFAULT NULL,
  `minimum_quantity` decimal(15,3) unsigned NOT NULL DEFAULT '0.000',
  `notes` text COLLATE utf8mb4_unicode_ci,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_by` bigint unsigned DEFAULT NULL,
  `updated_by` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `salami_products_code_unique` (`code`),
  KEY `salami_products_created_by_foreign` (`created_by`),
  KEY `salami_products_updated_by_foreign` (`updated_by`),
  KEY `salami_products_is_active_current_quantity_index` (`is_active`,`current_quantity`),
  KEY `salami_products_name_index` (`name`),
  CONSTRAINT `salami_products_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `salami_products_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `salami_products`
--

LOCK TABLES `salami_products` WRITE;
/*!40000 ALTER TABLE `salami_products` DISABLE KEYS */;
INSERT INTO `salami_products` VALUES (1,'سلامي سادة','SAL-001','قطعة',192.000,8.000,10.000,20.000,NULL,1,12,NULL,'2026-08-21 20:14:54','2026-08-25 16:45:35'),(2,'سلامي حار','SAL-002','قطعة',148.000,8.500,11.000,15.000,NULL,1,12,NULL,'2026-08-21 20:14:54','2026-08-25 16:45:35'),(3,'سلامي مدخن','SAL-003','قطعة',77.000,9.500,12.500,12.000,NULL,1,12,NULL,'2026-08-21 20:14:54','2026-08-25 16:45:35'),(4,'سلامي شرائح','SAL-004','قطعة',43.000,7.000,9.200,10.000,NULL,1,12,NULL,'2026-08-21 20:14:54','2026-08-25 16:45:35');
/*!40000 ALTER TABLE `salami_products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `salami_receipt_items`
--

DROP TABLE IF EXISTS `salami_receipt_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `salami_receipt_items` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `receipt_id` bigint unsigned NOT NULL,
  `product_id` bigint unsigned NOT NULL,
  `product_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `unit` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `conversion_factor` decimal(15,3) unsigned NOT NULL DEFAULT '1.000',
  `expected_quantity` decimal(15,3) unsigned NOT NULL DEFAULT '0.000',
  `received_quantity` decimal(15,3) unsigned NOT NULL DEFAULT '0.000',
  `damaged_quantity` decimal(15,3) unsigned NOT NULL DEFAULT '0.000',
  `shortage_quantity` decimal(15,3) unsigned NOT NULL DEFAULT '0.000',
  `surplus_quantity` decimal(15,3) unsigned NOT NULL DEFAULT '0.000',
  `accepted_quantity` decimal(15,3) unsigned NOT NULL DEFAULT '0.000',
  `accepted_stock_quantity` decimal(15,3) unsigned NOT NULL DEFAULT '0.000',
  `purchase_price` decimal(12,3) unsigned DEFAULT NULL,
  `balance_before` decimal(15,3) unsigned DEFAULT NULL,
  `balance_after` decimal(15,3) unsigned DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `salami_receipt_items_receipt_id_product_id_unique` (`receipt_id`,`product_id`),
  KEY `salami_receipt_items_product_id_index` (`product_id`),
  CONSTRAINT `salami_receipt_items_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `salami_products` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `salami_receipt_items_receipt_id_foreign` FOREIGN KEY (`receipt_id`) REFERENCES `salami_receipts` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `salami_receipt_items_quantities_check` CHECK (((`damaged_quantity` <= `received_quantity`) and (`shortage_quantity` = (case when (`expected_quantity` > `received_quantity`) then (`expected_quantity` - `received_quantity`) else 0 end)) and (`surplus_quantity` = (case when (`received_quantity` > `expected_quantity`) then (`received_quantity` - `expected_quantity`) else 0 end)) and (`accepted_quantity` = (`received_quantity` - `damaged_quantity`))))
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `salami_receipt_items`
--

LOCK TABLES `salami_receipt_items` WRITE;
/*!40000 ALTER TABLE `salami_receipt_items` DISABLE KEYS */;
INSERT INTO `salami_receipt_items` VALUES (1,1,1,'سلامي سادة','صندوق',1.000,100.000,96.000,2.000,4.000,0.000,94.000,94.000,80.000,120.000,214.000,NULL,'2026-08-21 20:14:54','2026-08-21 20:14:54'),(2,1,2,'سلامي حار','صندوق',1.000,60.000,66.000,1.000,0.000,6.000,65.000,65.000,85.000,90.000,155.000,NULL,'2026-08-21 20:14:54','2026-08-21 20:14:54'),(3,2,3,'سلامي مدخن','صندوق',1.000,40.000,40.000,0.000,0.000,0.000,40.000,40.000,95.000,45.000,85.000,NULL,'2026-08-21 20:14:55','2026-08-21 20:14:55'),(4,2,4,'سلامي شرائح','صندوق',1.000,25.000,25.000,0.000,0.000,0.000,25.000,25.000,70.000,18.000,43.000,NULL,'2026-08-21 20:14:55','2026-08-21 20:14:55'),(5,3,1,'سلامي سادة','صندوق',1.000,30.000,30.000,0.000,0.000,0.000,30.000,30.000,80.000,NULL,NULL,NULL,'2026-08-21 20:14:55','2026-08-21 20:14:55');
/*!40000 ALTER TABLE `salami_receipt_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `salami_receipts`
--

DROP TABLE IF EXISTS `salami_receipts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `salami_receipts` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `receipt_number` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `supplier_id` bigint unsigned NOT NULL,
  `supplier_invoice_number` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `receipt_date` date NOT NULL,
  `status` enum('draft','confirmed','cancelled') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'draft',
  `notes` text COLLATE utf8mb4_unicode_ci,
  `created_by` bigint unsigned NOT NULL,
  `confirmed_by` bigint unsigned DEFAULT NULL,
  `confirmed_at` timestamp NULL DEFAULT NULL,
  `cancelled_by` bigint unsigned DEFAULT NULL,
  `cancelled_at` timestamp NULL DEFAULT NULL,
  `cancellation_reason` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `updated_by` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `salami_receipts_receipt_number_unique` (`receipt_number`),
  KEY `salami_receipts_created_by_foreign` (`created_by`),
  KEY `salami_receipts_confirmed_by_foreign` (`confirmed_by`),
  KEY `salami_receipts_cancelled_by_foreign` (`cancelled_by`),
  KEY `salami_receipts_supplier_id_receipt_date_index` (`supplier_id`,`receipt_date`),
  KEY `salami_receipts_status_receipt_date_index` (`status`,`receipt_date`),
  KEY `salami_receipts_supplier_invoice_number_index` (`supplier_invoice_number`),
  KEY `salami_receipts_updated_by_foreign` (`updated_by`),
  CONSTRAINT `salami_receipts_cancelled_by_foreign` FOREIGN KEY (`cancelled_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `salami_receipts_confirmed_by_foreign` FOREIGN KEY (`confirmed_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `salami_receipts_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `salami_receipts_supplier_id_foreign` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `salami_receipts_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `salami_receipts`
--

LOCK TABLES `salami_receipts` WRITE;
/*!40000 ALTER TABLE `salami_receipts` DISABLE KEYS */;
INSERT INTO `salami_receipts` VALUES (1,'SAL-R-01M0JZCME3YS8R6ZMFQG0ET7XG',8,'SUP-SAL-1001','2026-08-18','confirmed','استلام بضاعة تجريبي مع نقص وتالف',12,12,'2026-08-21 20:14:54',NULL,NULL,NULL,'2026-08-21 20:14:54','2026-08-21 20:14:54',NULL),(2,'SAL-R-01M0JZCMHF9Y6ECN809Q1YEEZZ',10,'SUP-SAL-1002','2026-08-20','confirmed',NULL,12,12,'2026-08-21 20:14:55',NULL,NULL,NULL,'2026-08-21 20:14:55','2026-08-21 20:14:55',NULL),(3,'SAL-R-01M0JZCMNN1ZMRK6X3F5TQDJH8',8,NULL,'2026-08-21','draft','مسودة للعرض في النظام',12,NULL,NULL,NULL,NULL,NULL,'2026-08-21 20:14:55','2026-08-21 20:14:55',NULL);
/*!40000 ALTER TABLE `salami_receipts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES ('1HZpzwhhC6VbmsytDZ20jfNw9JP9pSRTniMq1sph',12,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:153.0) Gecko/20100101 Firefox/153.0','eyJfdG9rZW4iOiJQa0hiaUp1cjlCRUpmZFZ0enpEeVdXbGlKUXhTRG5BcER5a0hSRWl1IiwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119LCJfcHJldmlvdXMiOnsidXJsIjoiaHR0cDpcL1wvMTI3LjAuMC4xOjgwMDBcL3NhbGFtaVwvY3VzdG9tZXJzIiwicm91dGUiOiJzYWxhbWkuY3VzdG9tZXJzLmluZGV4In0sImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjoxMn0=',1787344556);
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stock_adjustments`
--

DROP TABLE IF EXISTS `stock_adjustments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stock_adjustments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `stockable_type` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `stockable_id` bigint unsigned NOT NULL,
  `system_quantity` decimal(15,3) unsigned NOT NULL,
  `actual_quantity` decimal(15,3) unsigned NOT NULL,
  `difference_quantity` decimal(15,3) NOT NULL,
  `adjustment_date` date NOT NULL,
  `reason` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `status` enum('confirmed','cancelled') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'confirmed',
  `created_by` bigint unsigned NOT NULL,
  `confirmed_by` bigint unsigned DEFAULT NULL,
  `confirmed_at` timestamp NULL DEFAULT NULL,
  `cancelled_by` bigint unsigned DEFAULT NULL,
  `cancelled_at` timestamp NULL DEFAULT NULL,
  `cancellation_reason` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `stock_adjustments_created_by_foreign` (`created_by`),
  KEY `stock_adjustments_confirmed_by_foreign` (`confirmed_by`),
  KEY `stock_adjustments_cancelled_by_foreign` (`cancelled_by`),
  KEY `stock_adjustments_stockable_index` (`stockable_type`,`stockable_id`),
  KEY `stock_adjustments_status_adjustment_date_index` (`status`,`adjustment_date`),
  CONSTRAINT `stock_adjustments_cancelled_by_foreign` FOREIGN KEY (`cancelled_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `stock_adjustments_confirmed_by_foreign` FOREIGN KEY (`confirmed_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `stock_adjustments_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `stock_adjustments_difference_check` CHECK ((`difference_quantity` = (cast(`actual_quantity` as decimal(15,3)) - cast(`system_quantity` as decimal(15,3)))))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stock_adjustments`
--

LOCK TABLES `stock_adjustments` WRITE;
/*!40000 ALTER TABLE `stock_adjustments` DISABLE KEYS */;
INSERT INTO `stock_adjustments` VALUES (1,'salami_product',2,145.000,148.000,3.000,'2026-08-21','فرق جرد بسيط','بيانات تجريبية','confirmed',12,12,'2026-08-21 20:14:55',NULL,NULL,NULL,'2026-08-21 20:14:55','2026-08-21 20:14:55'),(2,'flower_product',16,225.000,220.000,-5.000,'2026-08-21','فرق جرد ورد بسيط','تسوية تجريبية للعرض','confirmed',12,12,'2026-08-21 20:14:56',NULL,NULL,NULL,'2026-08-21 20:14:56','2026-08-21 20:14:56');
/*!40000 ALTER TABLE `stock_adjustments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stock_movements`
--

DROP TABLE IF EXISTS `stock_movements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stock_movements` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `stockable_type` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `stockable_id` bigint unsigned NOT NULL,
  `movement_type` enum('opening','receipt','sale','manual_exit','waste','adjustment_in','adjustment_out','reversal') COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` decimal(15,3) NOT NULL,
  `balance_before` decimal(15,3) unsigned NOT NULL,
  `balance_after` decimal(15,3) unsigned NOT NULL,
  `reference_type` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference_id` bigint unsigned DEFAULT NULL,
  `reverses_movement_id` bigint unsigned DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `created_by` bigint unsigned NOT NULL,
  `occurred_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `stock_movements_reference_type_unique` (`reference_type`,`reference_id`,`movement_type`),
  UNIQUE KEY `stock_movements_reverses_movement_id_unique` (`reverses_movement_id`),
  KEY `stock_movements_created_by_foreign` (`created_by`),
  KEY `stock_movements_stockable_index` (`stockable_type`,`stockable_id`),
  KEY `stock_movements_reference_index` (`reference_type`,`reference_id`),
  KEY `stock_movements_movement_type_occurred_at_index` (`movement_type`,`occurred_at`),
  CONSTRAINT `stock_movements_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `stock_movements_reverses_movement_id_foreign` FOREIGN KEY (`reverses_movement_id`) REFERENCES `stock_movements` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `stock_movements_balances_check` CHECK (((`quantity` <> 0) and (`balance_before` >= 0) and (`balance_after` >= 0) and (`balance_after` = (`balance_before` + `quantity`))))
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stock_movements`
--

LOCK TABLES `stock_movements` WRITE;
/*!40000 ALTER TABLE `stock_movements` DISABLE KEYS */;
INSERT INTO `stock_movements` VALUES (14,'salami_product',1,'opening',120.000,0.000,120.000,'stock_opening',7,NULL,'رصيد افتتاحي تجريبي',12,'2026-08-21 20:14:54','2026-08-21 20:14:54','2026-08-21 20:14:54'),(15,'salami_product',2,'opening',90.000,0.000,90.000,'stock_opening',8,NULL,'رصيد افتتاحي تجريبي',12,'2026-08-21 20:14:54','2026-08-21 20:14:54','2026-08-21 20:14:54'),(16,'salami_product',3,'opening',45.000,0.000,45.000,'stock_opening',9,NULL,'رصيد افتتاحي تجريبي',12,'2026-08-21 20:14:54','2026-08-21 20:14:54','2026-08-21 20:14:54'),(17,'salami_product',4,'opening',18.000,0.000,18.000,'stock_opening',10,NULL,'رصيد افتتاحي تجريبي',12,'2026-08-21 20:14:54','2026-08-21 20:14:54','2026-08-21 20:14:54'),(18,'flower_product',14,'opening',100.000,0.000,100.000,'stock_opening',11,NULL,'رصيد افتتاحي تجريبي',12,'2026-08-21 20:14:54','2026-08-21 20:14:54','2026-08-21 20:14:54'),(19,'flower_product',15,'opening',70.000,0.000,70.000,'stock_opening',12,NULL,'رصيد افتتاحي تجريبي',12,'2026-08-21 20:14:54','2026-08-21 20:14:54','2026-08-21 20:14:54'),(20,'flower_product',16,'opening',120.000,0.000,120.000,'stock_opening',13,NULL,'رصيد افتتاحي تجريبي',12,'2026-08-21 20:14:54','2026-08-21 20:14:54','2026-08-21 20:14:54'),(21,'flower_product',17,'opening',40.000,0.000,40.000,'stock_opening',14,NULL,'رصيد افتتاحي تجريبي',12,'2026-08-21 20:14:54','2026-08-21 20:14:54','2026-08-21 20:14:54'),(22,'salami_product',1,'receipt',94.000,120.000,214.000,'salami_receipt_item',1,NULL,'استلام SAL-R-01M0JZCME3YS8R6ZMFQG0ET7XG',12,'2026-08-21 20:14:54','2026-08-21 20:14:54','2026-08-21 20:14:54'),(23,'salami_product',2,'receipt',65.000,90.000,155.000,'salami_receipt_item',2,NULL,'استلام SAL-R-01M0JZCME3YS8R6ZMFQG0ET7XG',12,'2026-08-21 20:14:54','2026-08-21 20:14:54','2026-08-21 20:14:54'),(24,'salami_product',3,'receipt',40.000,45.000,85.000,'salami_receipt_item',3,NULL,'استلام SAL-R-01M0JZCMHF9Y6ECN809Q1YEEZZ',12,'2026-08-21 20:14:55','2026-08-21 20:14:55','2026-08-21 20:14:55'),(25,'salami_product',4,'receipt',25.000,18.000,43.000,'salami_receipt_item',4,NULL,'استلام SAL-R-01M0JZCMHF9Y6ECN809Q1YEEZZ',12,'2026-08-21 20:14:55','2026-08-21 20:14:55','2026-08-21 20:14:55'),(26,'salami_product',1,'sale',-18.000,214.000,196.000,'salami_invoice_item',1,NULL,'بيع عبر الفاتورة SAL-I-01M0JZCMQF7DSXGSWMDQQ6N4JS',12,'2026-08-21 20:14:55','2026-08-21 20:14:55','2026-08-21 20:14:55'),(27,'salami_product',2,'sale',-10.000,155.000,145.000,'salami_invoice_item',2,NULL,'بيع عبر الفاتورة SAL-I-01M0JZCMQF7DSXGSWMDQQ6N4JS',12,'2026-08-21 20:14:55','2026-08-21 20:14:55','2026-08-21 20:14:55'),(28,'salami_product',3,'sale',-8.000,85.000,77.000,'salami_invoice_item',3,NULL,'بيع عبر الفاتورة SAL-I-01M0JZCMYBP880K4P9CE1R50SD',12,'2026-08-21 20:14:55','2026-08-21 20:14:55','2026-08-21 20:14:55'),(29,'salami_product',1,'waste',-4.000,196.000,192.000,'stock_waste',4,NULL,'تالف: تالف أثناء التخزين',12,'2026-08-21 20:14:55','2026-08-21 20:14:55','2026-08-21 20:14:55'),(30,'salami_product',2,'adjustment_in',3.000,145.000,148.000,'stock_adjustment',1,NULL,'تسوية مخزون: فرق جرد بسيط',12,'2026-08-21 20:14:55','2026-08-21 20:14:55','2026-08-21 20:14:55'),(31,'flower_product',14,'receipt',270.000,100.000,370.000,'flower_receipt_item',8,NULL,'استلام ورد FL-R-01M0JZCN70CA8EPW17430VBMQD',12,'2026-08-21 20:14:55','2026-08-21 20:14:55','2026-08-21 20:14:55'),(32,'flower_product',15,'receipt',215.000,70.000,285.000,'flower_receipt_item',9,NULL,'استلام ورد FL-R-01M0JZCN70CA8EPW17430VBMQD',12,'2026-08-21 20:14:55','2026-08-21 20:14:55','2026-08-21 20:14:55'),(33,'flower_product',16,'receipt',150.000,120.000,270.000,'flower_receipt_item',10,NULL,'استلام ورد FL-R-01M0JZCNAZW30FBE6H20A7VYT8',12,'2026-08-21 20:14:55','2026-08-21 20:14:55','2026-08-21 20:14:55'),(34,'flower_product',17,'receipt',72.000,40.000,112.000,'flower_receipt_item',11,NULL,'استلام ورد FL-R-01M0JZCNAZW30FBE6H20A7VYT8',12,'2026-08-21 20:14:55','2026-08-21 20:14:55','2026-08-21 20:14:55'),(35,'flower_product',14,'sale',-90.000,370.000,280.000,'flower_invoice_item',1,NULL,'بيع ورد عبر الفاتورة FL-I-01M0JZCNEXBGEZ8V6SZ4JPCK55',12,'2026-08-21 20:14:56','2026-08-21 20:14:56','2026-08-21 20:14:56'),(36,'flower_product',15,'sale',-60.000,285.000,225.000,'flower_invoice_item',2,NULL,'بيع ورد عبر الفاتورة FL-I-01M0JZCNEXBGEZ8V6SZ4JPCK55',12,'2026-08-21 20:14:56','2026-08-21 20:14:56','2026-08-21 20:14:56'),(37,'flower_product',16,'sale',-45.000,270.000,225.000,'flower_invoice_item',3,NULL,'بيع ورد عبر الفاتورة FL-I-01M0JZCNHFDSE9K6RGD2ZF7RXX',12,'2026-08-21 20:14:56','2026-08-21 20:14:56','2026-08-21 20:14:56'),(38,'flower_product',14,'waste',-8.000,280.000,272.000,'stock_waste',5,NULL,'تالف ورد: ذبول',12,'2026-08-21 20:14:56','2026-08-21 20:14:56','2026-08-21 20:14:56'),(39,'flower_product',15,'manual_exit',-12.000,225.000,213.000,'flower_exit',4,NULL,'خروج ورد يدوي: gift',12,'2026-08-21 20:14:56','2026-08-21 20:14:56','2026-08-21 20:14:56'),(40,'flower_product',16,'adjustment_out',-5.000,225.000,220.000,'stock_adjustment',2,NULL,'تسوية مخزون ورد تجريبية',12,'2026-08-21 20:14:56','2026-08-21 20:14:56','2026-08-21 20:14:56'),(41,'flower_product',18,'opening',90.000,0.000,90.000,'stock_opening',15,NULL,'رصيد افتتاحي تجريبي',12,'2026-08-21 20:15:29','2026-08-21 20:15:29','2026-08-21 20:15:29');
/*!40000 ALTER TABLE `stock_movements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stock_openings`
--

DROP TABLE IF EXISTS `stock_openings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stock_openings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `stockable_type` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `stockable_id` bigint unsigned NOT NULL,
  `quantity` decimal(15,3) unsigned NOT NULL,
  `opening_date` date NOT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `created_by` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `stock_openings_stockable_unique` (`stockable_type`,`stockable_id`),
  KEY `stock_openings_created_by_foreign` (`created_by`),
  KEY `stock_openings_opening_date_index` (`opening_date`),
  CONSTRAINT `stock_openings_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `stock_openings_quantity_check` CHECK ((`quantity` > 0))
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stock_openings`
--

LOCK TABLES `stock_openings` WRITE;
/*!40000 ALTER TABLE `stock_openings` DISABLE KEYS */;
INSERT INTO `stock_openings` VALUES (7,'salami_product',1,120.000,'2026-08-21','رصيد افتتاحي تجريبي',12,'2026-08-21 20:14:54','2026-08-21 20:14:54'),(8,'salami_product',2,90.000,'2026-08-21','رصيد افتتاحي تجريبي',12,'2026-08-21 20:14:54','2026-08-21 20:14:54'),(9,'salami_product',3,45.000,'2026-08-21','رصيد افتتاحي تجريبي',12,'2026-08-21 20:14:54','2026-08-21 20:14:54'),(10,'salami_product',4,18.000,'2026-08-21','رصيد افتتاحي تجريبي',12,'2026-08-21 20:14:54','2026-08-21 20:14:54'),(11,'flower_product',14,100.000,'2026-08-21','رصيد افتتاحي تجريبي',12,'2026-08-21 20:14:54','2026-08-21 20:14:54'),(12,'flower_product',15,70.000,'2026-08-21','رصيد افتتاحي تجريبي',12,'2026-08-21 20:14:54','2026-08-21 20:14:54'),(13,'flower_product',16,120.000,'2026-08-21','رصيد افتتاحي تجريبي',12,'2026-08-21 20:14:54','2026-08-21 20:14:54'),(14,'flower_product',17,40.000,'2026-08-21','رصيد افتتاحي تجريبي',12,'2026-08-21 20:14:54','2026-08-21 20:14:54'),(15,'flower_product',18,90.000,'2026-08-21','رصيد افتتاحي تجريبي',12,'2026-08-21 20:15:29','2026-08-21 20:15:29');
/*!40000 ALTER TABLE `stock_openings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stock_wastes`
--

DROP TABLE IF EXISTS `stock_wastes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stock_wastes` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `stockable_type` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `stockable_id` bigint unsigned NOT NULL,
  `quantity` decimal(15,3) unsigned NOT NULL,
  `reason` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `waste_date` date NOT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `status` enum('confirmed','cancelled') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'confirmed',
  `created_by` bigint unsigned NOT NULL,
  `confirmed_by` bigint unsigned DEFAULT NULL,
  `confirmed_at` timestamp NULL DEFAULT NULL,
  `cancelled_by` bigint unsigned DEFAULT NULL,
  `cancelled_at` timestamp NULL DEFAULT NULL,
  `cancellation_reason` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `stock_wastes_created_by_foreign` (`created_by`),
  KEY `stock_wastes_confirmed_by_foreign` (`confirmed_by`),
  KEY `stock_wastes_cancelled_by_foreign` (`cancelled_by`),
  KEY `stock_wastes_stockable_index` (`stockable_type`,`stockable_id`),
  KEY `stock_wastes_status_waste_date_index` (`status`,`waste_date`),
  CONSTRAINT `stock_wastes_cancelled_by_foreign` FOREIGN KEY (`cancelled_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `stock_wastes_confirmed_by_foreign` FOREIGN KEY (`confirmed_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `stock_wastes_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `stock_wastes_quantity_check` CHECK ((`quantity` > 0))
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stock_wastes`
--

LOCK TABLES `stock_wastes` WRITE;
/*!40000 ALTER TABLE `stock_wastes` DISABLE KEYS */;
INSERT INTO `stock_wastes` VALUES (4,'salami_product',1,4.000,'تالف أثناء التخزين','2026-08-21',NULL,'confirmed',12,12,'2026-08-21 20:14:55',NULL,NULL,NULL,'2026-08-21 20:14:55','2026-08-21 20:14:55'),(5,'flower_product',14,8.000,'ذبول','2026-08-21','تالف بعد التخزين','confirmed',12,12,'2026-08-21 20:14:56',NULL,NULL,NULL,'2026-08-21 20:14:56','2026-08-21 20:14:56');
/*!40000 ALTER TABLE `stock_wastes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `suppliers`
--

DROP TABLE IF EXISTS `suppliers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `suppliers` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `company_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `module_scope` enum('salami','flower','both') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'both',
  `notes` text COLLATE utf8mb4_unicode_ci,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_by` bigint unsigned DEFAULT NULL,
  `updated_by` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `suppliers_created_by_foreign` (`created_by`),
  KEY `suppliers_updated_by_foreign` (`updated_by`),
  KEY `suppliers_module_scope_is_active_index` (`module_scope`,`is_active`),
  KEY `suppliers_name_index` (`name`),
  CONSTRAINT `suppliers_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `suppliers_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `suppliers`
--

LOCK TABLES `suppliers` WRITE;
/*!40000 ALTER TABLE `suppliers` DISABLE KEYS */;
INSERT INTO `suppliers` VALUES (8,'شركة غذاء طرابلس','شركة غذاء طرابلس للتوريد','0910000001','ليبيا','salami',NULL,1,NULL,NULL,'2026-08-21 20:14:54','2026-08-21 20:14:54'),(9,'مشتل الياسمين','مشتل الياسمين للزهور','0910000002','ليبيا','flower',NULL,1,NULL,NULL,'2026-08-21 20:14:54','2026-08-21 20:14:54'),(10,'مخازن الساحل','مخازن الساحل للتجارة','0910000003','ليبيا','both',NULL,1,NULL,NULL,'2026-08-21 20:14:54','2026-08-21 20:14:54'),(11,'test','test','0915040043','تونس','flower','test',1,12,NULL,'2026-08-21 20:16:02','2026-08-21 20:16:02');
/*!40000 ALTER TABLE `suppliers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'employee',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  KEY `users_role_index` (`role`),
  KEY `users_is_active_index` (`is_active`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (12,'مدير النظام','admin@inventory.test','2026-08-25 16:47:28','$2y$12$jObQt5d/VproKF32TKzV3uFJRUaZdaA8fcpDuHndIjVHIkveaTMHm','admin',1,NULL,'2026-08-21 20:14:54','2026-08-25 16:47:28'),(13,'موظف المخزن','employee@inventory.test','2026-08-25 16:47:28','$2y$12$sJBF3Kzj8DRFZxBPVe90o.izc8s946YHvzcV9qFyVlpgP7CanChHy','employee',1,NULL,'2026-08-21 20:14:54','2026-08-25 16:47:28');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'inventory_system'
--

--
-- Dumping routines for database 'inventory_system'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-08-25 23:26:43
